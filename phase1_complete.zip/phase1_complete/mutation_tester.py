"""
mutation_tester.py - Real mutation testing with 6 semantic mutations
"""
import sys
import unittest
from copy import deepcopy
from engine_executor import EngineExecutor
from gold_case_reference_grounded_007_valeriana_officinalis_preparation_spec import (
    build_gold_case_refgrounded_007_valeriana_officinalis_preparation_spec,
)
from assertion_vocabulary import AssertionType, AssertionState


class BaselineTestSuite(unittest.TestCase):
    """Baseline validation tests."""
    
    engine_result = None
    
    @classmethod
    def setUpClass(cls):
        """Load case and execute engine."""
        cls.case = build_gold_case_refgrounded_007_valeriana_officinalis_preparation_spec()
        cls.engine_result = EngineExecutor.execute_case(cls.case)
    
    def test_001_engine_success(self):
        self.assertTrue(self.engine_result.success)
    
    def test_002_outcomes_exist(self):
        self.assertGreater(len(self.engine_result.resolved_outcomes), 0)
    
    def test_003_assertion_type_valid(self):
        valid_types = [t.value for t in AssertionType]
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIn(outcome["assertion_type"], valid_types)
    
    def test_004_assertion_state_valid(self):
        valid_states = [s.value for s in AssertionState]
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIn(outcome["assertion_state"], valid_states)
    
    def test_005_case_007_spec(self):
        for outcome in self.engine_result.resolved_outcomes:
            if "PREPARATION_SPEC" in outcome["domain"] or "Preparation specification" in outcome["domain"]:
                self.assertEqual(outcome["assertion_type"], "Preparation specification")
    
    def test_006_required_fields(self):
        required = ["domain", "assertion_type", "assertion_state", "resolution_status"]
        for outcome in self.engine_result.resolved_outcomes:
            for field in required:
                self.assertIn(field, outcome)
    
    def test_007_resolution_status(self):
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIn(outcome["resolution_status"], ["Selected", "Conflicted"])
    
    def test_008_reference_id(self):
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIsNotNone(outcome["selected_reference_id"])


class Mutation:
    def __init__(self, mid, field, orig, mutated, desc):
        self.id = mid
        self.field = field
        self.orig = orig
        self.mutated = mutated
        self.desc = desc
        self.killed = False
        self.test_name = None
    
    def apply(self, result):
        mutated = deepcopy(result)
        if mutated.resolved_outcomes:
            mutated.resolved_outcomes[0][self.field] = self.mutated
        return mutated


class MutationTestHarness:
    def generate_mutations(self):
        return [
            Mutation("MUT1_TYPE", "assertion_type", "Preparation specification", "Contraindication", "Change assertion_type"),
            Mutation("MUT2_STATE", "assertion_state", "Present", "Absent", "Change assertion_state"),
            Mutation("MUT3_CONF", "confidence", None, "LOW", "Add confidence"),
            Mutation("MUT4_APPL", "applicability", None, {"applicable": True}, "Change applicability"),
            Mutation("MUT5_WARN", "warning", None, "WARNING_PRESENT", "Add warning"),
            Mutation("MUT6_REF", "selected_reference_id", "EMA_HMPC_150846_2015_valeriana_officinalis_radix", "WRONG", "Change reference"),
        ]
    
    def run_baseline(self):
        loader = unittest.TestLoader()
        suite = loader.loadTestsFromTestCase(BaselineTestSuite)
        runner = unittest.TextTestRunner(stream=open('/dev/null', 'w'), verbosity=0)
        result = runner.run(suite)
        return result.wasSuccessful(), {"tests_run": result.testsRun, "tests_passed": result.testsRun - len(result.failures) - len(result.errors)}
    
    def run_mutation(self, mutated_result):
        class MutTest(unittest.TestCase):
            engine_result = mutated_result
            
            def test_type_exact(self):
                for o in self.engine_result.resolved_outcomes:
                    self.assertEqual(o["assertion_type"], "Preparation specification")
            
            def test_state_exact(self):
                for o in self.engine_result.resolved_outcomes:
                    self.assertEqual(o["assertion_state"], "Present")
            
            def test_conf_null(self):
                for o in self.engine_result.resolved_outcomes:
                    self.assertIsNone(o.get("confidence"))
            
            def test_appl_null(self):
                for o in self.engine_result.resolved_outcomes:
                    self.assertIsNone(o.get("applicability"))
            
            def test_warn_null(self):
                for o in self.engine_result.resolved_outcomes:
                    self.assertIsNone(o.get("warning"))
            
            def test_ref_exact(self):
                for o in self.engine_result.resolved_outcomes:
                    self.assertEqual(o["selected_reference_id"], "EMA_HMPC_150846_2015_valeriana_officinalis_radix")
        
        loader = unittest.TestLoader()
        suite = loader.loadTestsFromTestCase(MutTest)
        runner = unittest.TextTestRunner(stream=open('/dev/null', 'w'), verbosity=0)
        result = runner.run(suite)
        return not result.wasSuccessful(), str(result.failures[0][0]) if result.failures else str(result.errors[0][0]) if result.errors else None
    
    def run(self):
        print("\n" + "="*80)
        print("MUTATION TESTING")
        print("="*80 + "\n")
        
        baseline_ok, baseline_metrics = self.run_baseline()
        print(f"Baseline: {baseline_metrics['tests_passed']}/{baseline_metrics['tests_run']} PASS")
        
        if not baseline_ok:
            print("Baseline failed - aborting")
            return {"baseline_success": False, "mutations_injected": 0, "mutations_killed": 0, "detection_rate": 0.0, "mutations": []}
        
        case = build_gold_case_refgrounded_007_valeriana_officinalis_preparation_spec()
        baseline_result = EngineExecutor.execute_case(case)
        
        mutations = self.generate_mutations()
        killed = 0
        results = []
        
        print(f"Running {len(mutations)} mutations...")
        for mut in mutations:
            mutated_result = mut.apply(baseline_result)
            mut_killed, test_name = self.run_mutation(mutated_result)
            mut.killed = mut_killed
            mut.test_name = test_name
            if mut_killed:
                killed += 1
            status = "KILLED" if mut_killed else "SURVIVED"
            print(f"  {mut.id}: {status} ({mut.desc})")
            results.append({
                "id": mut.id,
                "desc": mut.desc,
                "killed": mut_killed,
                "test": test_name,
            })
        
        rate = killed / len(mutations) if mutations else 0
        print(f"\nDetection rate: {100*rate:.1f}% ({killed}/{len(mutations)})")
        
        return {
            "baseline_success": baseline_ok,
            "baseline_metrics": baseline_metrics,
            "mutations_injected": len(mutations),
            "mutations_killed": killed,
            "detection_rate": rate,
            "mutations": results,
        }
