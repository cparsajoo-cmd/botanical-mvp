"""
test_case_009_indication_evidence.py

Test Case 009: Melissa officinalis L. (leaf) - Sleep/relaxation indication evidence
"""

import unittest
from gold_case_reference_grounded_009_melissa_officinalis_indication_evidence import (
    build_gold_case_refgrounded_009_melissa_officinalis_indication_evidence,
)
from engine_executor import EngineExecutor
from assertion_vocabulary import AssertionType, AssertionState


class TestCase009IndicationEvidence(unittest.TestCase):
    """Test Case 009 - Melissa officinalis sleep/relaxation indication evidence."""
    
    @classmethod
    def setUpClass(cls):
        """Load case and execute engine."""
        cls.case = build_gold_case_refgrounded_009_melissa_officinalis_indication_evidence()
        cls.engine_result = EngineExecutor.execute_case(cls.case)
    
    def test_001_case_loads_successfully(self):
        """Case 009 loads without error."""
        self.assertIsNotNone(self.case)
        self.assertEqual(self.case.case_id, "refgrounded_009_melissa_officinalis_indication_evidence")
    
    def test_002_melissa_officinalis_taxon_correct(self):
        """Case is for Melissa officinalis L. leaf."""
        self.assertEqual(self.case.validation_unit.taxon, "Melissa officinalis L.")
        self.assertEqual(self.case.validation_unit.plant_part, "leaf")
    
    def test_003_indication_domain(self):
        """Domain is INDICATION_EVIDENCE."""
        self.assertEqual(self.case.domain, "INDICATION_EVIDENCE")
    
    def test_004_reference_present(self):
        """Case has verified reference."""
        self.assertEqual(len(self.case.references), 1)
        self.assertIsNotNone(self.case.references[0].reference)
    
    def test_005_engine_executes_successfully(self):
        """Engine execution succeeds for Case 009."""
        self.assertTrue(self.engine_result.success)
        self.assertIsNotNone(self.engine_result.resolved_outcomes)
    
    def test_006_indication_assertion_present(self):
        """Indication assertion is present."""
        self.assertGreater(len(self.engine_result.resolved_outcomes), 0)
        outcome = self.engine_result.resolved_outcomes[0]
        self.assertEqual(outcome["assertion_type"], "Supports indication")
        self.assertEqual(outcome["assertion_state"], "Present")
    
    def test_007_resolution_status_resolved(self):
        """Resolution status is Selected."""
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIn(outcome["resolution_status"], ["Selected", "Conflicted"])
    
    def test_008_reference_id_present(self):
        """Selected reference ID is present."""
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIsNotNone(outcome["selected_reference_id"])
            self.assertTrue(len(outcome["selected_reference_id"]) > 0)


if __name__ == "__main__":
    unittest.main()
