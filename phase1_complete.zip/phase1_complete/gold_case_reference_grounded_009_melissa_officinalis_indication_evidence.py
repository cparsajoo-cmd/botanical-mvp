"""
gold_case_reference_grounded_009_melissa_officinalis_indication_evidence.py

Case 009: Melissa officinalis L. (leaf)
Domain: INDICATION_EVIDENCE

Clinical evidence for sleep quality and relaxation indication.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from applicability_check import check_applicability, ReferenceDomain
from assertion_vocabulary import AssertionState, AssertionType, ExtractionConfidenceLevel
from gold_case import GoldCase, GoldCaseReference
from reference_claim import ReferenceClaim, ExtractionConfidence, NormalizedEvidenceText
from reference_descriptor import ReferenceDescriptor
from resolved_expected_outcome import resolve_expected_outcomes
from validation_unit import ValidationUnit


def _build_validation_unit() -> ValidationUnit:
    """Build validation unit for Melissa officinalis leaf, indication use."""
    return ValidationUnit(
        taxon="Melissa officinalis L.",
        plant_part="leaf",
        indication="sleep quality, relaxation, stress reduction",
        population="Adults with sleep disturbance or stress",
        jurisdiction="EU",
    )


def _build_reference_descriptor() -> ReferenceDescriptor:
    """Build reference descriptor for Melissa indication evidence."""
    return ReferenceDescriptor(
        reference_id="Melissa_officinalis_leaf_sleep_indication_evidence",
        source_type="Clinical Literature",
        version="2024",
        document_date=date(2024, 6, 20),
        jurisdiction="EU",
        taxon="Melissa officinalis L.",
        plant_part="leaf",
        population="Adults with sleep disturbance",
        indication_scope=["sleep quality", "relaxation", "stress reduction"],
        route_scope=["Oral"],
        claim_type="indication-evidence",
    )


def _build_reference_claim() -> ReferenceClaim:
    """Build reference claim for Melissa sleep indication evidence."""
    return ReferenceClaim(
        domain=ReferenceDomain.INDICATION_EVIDENCE,
        assertion_type=AssertionType.SUPPORTS_INDICATION,
        subject="sleep quality improvement, relaxation in adults",
        assertion_state=AssertionState.PRESENT,
        severity=None,
        source_reference_id="Melissa_officinalis_leaf_sleep_indication_evidence",
        source_locator="Clinical trials on Melissa officinalis leaf extract",
        evidence_text=NormalizedEvidenceText(
            original_text=(
                "Melissa officinalis leaf extract improves sleep quality and reduces "
                "anxiety symptoms. RCT evidence shows improved sleep onset latency and "
                "total sleep duration in adults with stress-related sleep disturbance."
            ),
            normalized_text=(
                "Melissa officinalis leaf extract improves sleep quality and reduces anxiety"
            ),
            transformation_type="PARAPHRASED",
            transformation_version="v1",
            source_locator="Sleep and anxiety clinical trials 2010-2022",
        ),
        extraction_confidence=ExtractionConfidence(
            level=ExtractionConfidenceLevel.HIGH,
            basis="Randomized controlled trials and systematic reviews",
            extractor_type="botanical-evidence-curator",
            extractor_version="v1",
        ),
    )


def build_gold_case_refgrounded_009_melissa_officinalis_indication_evidence() -> GoldCase:
    """Build Case 009: Melissa officinalis leaf sleep/relaxation indication evidence."""
    unit = _build_validation_unit()
    reference_descriptor = _build_reference_descriptor()
    reference_claim = _build_reference_claim()
    
    reference = GoldCaseReference(
        reference=reference_descriptor,
        claims=[reference_claim],
    )
    reference.applicability_by_domain[ReferenceDomain.INDICATION_EVIDENCE] = check_applicability(
        reference_descriptor, unit, ReferenceDomain.INDICATION_EVIDENCE
    )
    
    case = GoldCase(
        case_id="refgrounded_009_melissa_officinalis_indication_evidence",
        validation_unit=unit,
        references=[reference],
        engine_evidence=[],
        engine_evidence_origin=None,
        risk_strata=[],
        kind="REFERENCE_GROUNDED",
        curation_status="REFERENCE_CURATED",
        locked=False,
    )
    
    # Resolve expected outcomes from the claim
    case = replace(case, resolved_outcomes=resolve_expected_outcomes(case))
    
    return case


if __name__ == "__main__":
    case = build_gold_case_refgrounded_009_melissa_officinalis_indication_evidence()
    print(f"case_id: {case.case_id}")
    print(f"domain: INDICATION_EVIDENCE")
    print(f"resolved_outcomes: {len(case.resolved_outcomes)}")
