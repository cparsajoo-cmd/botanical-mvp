"""
test_case_011_safety_evidence.py

Test Case 011: Matricaria chamomilla L. (flower) - Safety evidence
"""

import unittest
from gold_case_reference_grounded_011_matricaria_chamomilla_safety_evidence import (
    build_gold_case_refgrounded_011_matricaria_chamomilla_safety_evidence,
)
from engine_executor import EngineExecutor
from assertion_vocabulary import AssertionType, AssertionState


class TestCase011SafetyEvidence(unittest.TestCase):
    """Test Case 011 - Matricaria chamomilla safety evidence."""
    
    @classmethod
    def setUpClass(cls):
        """Load case and execute engine."""
        cls.case = build_gold_case_refgrounded_011_matricaria_chamomilla_safety_evidence()
        cls.engine_result = EngineExecutor.execute_case(cls.case)
    
    def test_001_case_loads_successfully(self):
        """Case 011 loads without error."""
        self.assertIsNotNone(self.case)
        self.assertEqual(self.case.case_id, "refgrounded_011_matricaria_chamomilla_safety_evidence")
    
    def test_002_matricaria_chamomilla_taxon_correct(self):
        """Case is for Matricaria chamomilla L. flower."""
        self.assertEqual(self.case.validation_unit.taxon, "Matricaria chamomilla L.")
        self.assertEqual(self.case.validation_unit.plant_part, "flower")
    
    def test_003_safety_domain(self):
        """Domain is SAFETY."""
        self.assertEqual(self.case.domain, "SAFETY")
    
    def test_004_reference_present(self):
        """Case has verified reference."""
        self.assertEqual(len(self.case.references), 1)
        self.assertIsNotNone(self.case.references[0].reference)
    
    def test_005_engine_executes_successfully(self):
        """Engine execution succeeds for Case 011."""
        self.assertTrue(self.engine_result.success)
        self.assertIsNotNone(self.engine_result.resolved_outcomes)
    
    def test_006_safety_assertion_present(self):
        """Safety assertion is present."""
        self.assertGreater(len(self.engine_result.resolved_outcomes), 0)
        outcome = self.engine_result.resolved_outcomes[0]
        self.assertEqual(outcome["assertion_type"], "Supports indication")
        self.assertEqual(outcome["assertion_state"], "Present")
    
    def test_007_resolution_status_resolved(self):
        """Resolution status is Selected."""
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIn(outcome["resolution_status"], ["Selected", "Conflicted"])
    
    def test_008_reference_id_present(self):
        """Selected reference ID is present."""
        for outcome in self.engine_result.resolved_outcomes:
            self.assertIsNotNone(outcome["selected_reference_id"])
            self.assertTrue(len(outcome["selected_reference_id"]) > 0)


if __name__ == "__main__":
    unittest.main()
