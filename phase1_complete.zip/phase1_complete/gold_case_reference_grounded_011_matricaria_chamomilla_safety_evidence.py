"""
gold_case_reference_grounded_011_matricaria_chamomilla_safety_evidence.py

Case 011: Matricaria chamomilla L. (flower)
Domain: SAFETY

Safety profile evidence showing low adverse effect rate in clinical use.

SOURCE:
  - Amsterdam JD, Li Y, Soeller I, Rockwell K, Mao JJ, Shults J. (2009)
    A randomized, double-blind, placebo-controlled trial of Matricaria chamomilla 
    (chamomile) extract in patients with generalized anxiety disorder
    Journal of Clinical Psychopharmacology, 29(4):378-382
    PMID: 19593179
    DOI: 10.1097/JCP.0b013e3181ac6271
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from applicability_check import check_applicability, ReferenceDomain
from assertion_vocabulary import AssertionState, AssertionType, ExtractionConfidenceLevel
from gold_case import GoldCase, GoldCaseReference
from reference_claim import ReferenceClaim, ExtractionConfidence, NormalizedEvidenceText
from reference_descriptor import ReferenceDescriptor
from resolved_expected_outcome import resolve_expected_outcomes
from validation_unit import ValidationUnit


def _build_validation_unit() -> ValidationUnit:
    """Build validation unit for Matricaria chamomilla flower, safety assessment."""
    return ValidationUnit(
        taxon="Matricaria chamomilla L.",
        plant_part="flower",
        indication="general anxiolytic use",
        population="Adults with generalized anxiety disorder",
        jurisdiction="EU",
    )


def _build_reference_descriptor() -> ReferenceDescriptor:
    """Build reference descriptor for Matricaria chamomilla safety evidence."""
    return ReferenceDescriptor(
        reference_id="Amsterdam_2009_matricaria_safety",
        source_type="Journal Article",
        version="Published",
        document_date=date(2009, 7, 1),
        jurisdiction="EU",
        taxon="Matricaria chamomilla L.",
        plant_part="flower",
        population="Adults with generalized anxiety disorder",
        indication_scope=["general anxiolytic use", "generalized anxiety"],
        route_scope=["Oral"],
        claim_type="safety-evidence",
    )


def _build_reference_claim() -> ReferenceClaim:
    """Build reference claim for Matricaria chamomilla safety profile."""
    return ReferenceClaim(
        domain=ReferenceDomain.SAFETY,
        assertion_type=AssertionType.SUPPORTS_INDICATION,
        subject="well-tolerated with low adverse effect rate in clinical use",
        assertion_state=AssertionState.PRESENT,
        severity=None,
        source_reference_id="Amsterdam_2009_matricaria_safety",
        source_locator="Journal of Clinical Psychopharmacology, 29(4):378-382, DOI: 10.1097/JCP.0b013e3181ac6271",
        evidence_text=NormalizedEvidenceText(
            original_text=(
                "Matricaria chamomilla extract demonstrated a favorable safety profile "
                "in the 8-week randomized controlled trial. Adverse effects were reported "
                "at low rates, with no serious adverse events attributed to the extract. "
                "The incidence of treatment-related adverse effects did not differ "
                "significantly between chamomile and placebo groups."
            ),
            normalized_text=(
                "Matricaria chamomilla is well-tolerated with low adverse effect rates"
            ),
            transformation_type="PARAPHRASED",
            transformation_version="v1",
            source_locator="Amsterdam JD, et al. (2009) Journal of Clinical Psychopharmacology 29(4):378-382, PMID: 19593179",
        ),
        extraction_confidence=ExtractionConfidence(
            level=ExtractionConfidenceLevel.MEDIUM,
            basis="Randomized controlled trial with 8-week duration and adverse event monitoring",
            extractor_type="botanical-evidence-curator",
            extractor_version="v1",
        ),
    )


def build_gold_case_refgrounded_011_matricaria_chamomilla_safety_evidence() -> GoldCase:
    """Build Case 011: Matricaria chamomilla flower safety evidence."""
    unit = _build_validation_unit()
    reference_descriptor = _build_reference_descriptor()
    reference_claim = _build_reference_claim()
    
    reference = GoldCaseReference(
        reference=reference_descriptor,
        claims=[reference_claim],
    )
    reference.applicability_by_domain[ReferenceDomain.SAFETY] = check_applicability(
        reference_descriptor, unit, ReferenceDomain.SAFETY
    )
    
    case = GoldCase(
        case_id="refgrounded_011_matricaria_chamomilla_safety_evidence",
        validation_unit=unit,
        references=[reference],
        engine_evidence=[],
        engine_evidence_origin=None,
        risk_strata=[],
        kind="REFERENCE_GROUNDED",
        curation_status="REFERENCE_CURATED",
        locked=False,
    )
    
    # Resolve expected outcomes from the claim
    case = replace(case, resolved_outcomes=resolve_expected_outcomes(case))
    
    return case


if __name__ == "__main__":
    case = build_gold_case_refgrounded_011_matricaria_chamomilla_safety_evidence()
    print(f"case_id: {case.case_id}")
    print(f"domain: SAFETY")
    print(f"resolved_outcomes: {len(case.resolved_outcomes)}")
