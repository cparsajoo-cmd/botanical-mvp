#!/usr/bin/env python3
"""
run_validation.py

PHASE 1 COMPLETE VALIDATION
"""

import sys
import json
import hashlib
import subprocess
import argparse
from pathlib import Path
from datetime import datetime
from io import StringIO

sys.path.insert(0, str(Path(__file__).parent))

from mutation_tester import MutationTestHarness, BaselineTestSuite
from engine_executor import EngineExecutor
from gold_case_reference_grounded_007_valeriana_officinalis_preparation_spec import (
    build_gold_case_refgrounded_007_valeriana_officinalis_preparation_spec,
)
from pipeline_state_machine import (
    PipelineStateRecord, PipelineState, VerificationStatus,
    LEGAL_TRANSITIONS,
)
import unittest


def compute_sha256(file_path: Path) -> str:
    """Compute SHA-256 of file."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def run_baseline_tests() -> tuple:
    """Run baseline test suite."""
    print("SUITE 1: BASELINE INTEGRATION TESTS")
    print("-" * 80)
    
    output = StringIO()
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(BaselineTestSuite)
    runner = unittest.TextTestRunner(stream=output, verbosity=2)
    result = runner.run(suite)
    
    output_text = output.getvalue()
    print(output_text)
    
    status = "PASS" if result.wasSuccessful() else "FAIL"
    
    report = f"""BASELINE INTEGRATION TESTS
================================================================================

Tests run: {result.testsRun}
Passed: {result.testsRun - len(result.failures) - len(result.errors)}
Failed: {len(result.failures)}
Errors: {len(result.errors)}

Status: {status}
"""
    
    return result.wasSuccessful(), report, result.testsRun


def run_regression_tests() -> tuple:
    """Regression test: try Case 007 test file."""
    print("\nSUITE 2: REGRESSION TESTS (Case 007)")
    print("-" * 80)
    
    try:
        result = subprocess.run(
            [sys.executable, "test_case_007_preparation_specification.py"],
            cwd=Path(__file__).parent,
            capture_output=True,
            text=True,
            timeout=10,
        )
        
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        
        success = result.returncode == 0
    except Exception as e:
        success = False
        result = type('obj', (object,), {
            'returncode': 1,
            'stdout': f'Error: {e}',
            'stderr': str(e)
        })()
    
    status = "PASS" if success else "FAIL"
    
    report = f"""REGRESSION TESTS (Case 007)
================================================================================

Return code: {result.returncode}
Status: {status}

Output:
{result.stdout}
"""
    
    return success, report


def run_mutation_tests() -> tuple:
    """Run mutation testing."""
    print("\nSUITE 3: MUTATION TESTING")
    print("-" * 80)
    
    harness = MutationTestHarness()
    results = harness.run()
    
    success = (
        results["baseline_success"]
        and results["detection_rate"] == 1.0
    )
    
    report = f"""MUTATION TESTING
================================================================================

Baseline tests: {results['baseline_metrics']['tests_passed']} passed

Mutations injected: {results['mutations_injected']}
Mutations killed: {results['mutations_killed']}
Detection rate: {100*results['detection_rate']:.1f}%

Status: {'PASS' if success else 'FAIL'}

Mutation details:
"""
    
    for mutation in results["mutations"]:
        report += f"\n  {mutation['id']}: "
        if mutation["killed"]:
            report += f"KILLED by {mutation['test']}"
        else:
            report += "SURVIVED"
    
    return success, report, results


def validate_state_transitions() -> tuple:
    """Validate state machine transitions."""
    print("\nSUITE 4: STATE MACHINE TRANSITION VALIDATION")
    print("-" * 80)
    
    report = "STATE MACHINE TRANSITION VALIDATION\n"
    report += "=" * 80 + "\n\n"
    
    errors = []
    
    # Test: Illegal transitions
    report += "Testing illegal transitions (should be blocked):\n"
    
    illegal_transitions = [
        (PipelineState.DISCOVERED, PipelineState.ENGINE_VALIDATED, "Skipped states"),
        (PipelineState.ENGINE_VALIDATED, PipelineState.SOURCE_VERIFIED, "Backward transition"),
    ]
    
    for from_state, to_state, reason in illegal_transitions:
        record = PipelineStateRecord(case_id="test", current_state=from_state)
        success, error = record.advance_to_state(to_state)
        
        if success:
            errors.append(f"✗ {from_state} → {to_state} should have failed ({reason})")
            report += f"  ✗ FAILED: {from_state} → {to_state} ({reason})\n"
        else:
            report += f"  ✓ BLOCKED: {from_state} → {to_state}\n"
    
    # Test: Gate enforcement
    report += "\nTesting gate enforcement (should require artifacts):\n"
    
    record = PipelineStateRecord(case_id="test", current_state=PipelineState.SOURCE_RETRIEVED)
    success, error = record.advance_to_state(PipelineState.SOURCE_VERIFIED)
    
    if success:
        errors.append("✗ SOURCE_VERIFIED should require VerificationStatus.VERIFIED")
        report += f"  ✗ FAILED: Gate not enforced\n"
    else:
        report += f"  ✓ BLOCKED: Gate enforced\n"
    
    success = len(errors) == 0
    
    return success, report


def generate_execution_trace(case, engine_result) -> dict:
    """Generate execution trace JSON."""
    return {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "case_id": case.case_id,
        "engine_execution_trace": engine_result.execution_trace,
        "outcomes_count": len(engine_result.resolved_outcomes),
        "first_outcome": engine_result.resolved_outcomes[0] if engine_result.resolved_outcomes else None,
    }


def generate_sha256_manifest(output_dir: Path) -> str:
    """Generate SHA-256 manifest of all files."""
    manifest_lines = ["SHA-256 Manifest\n"]
    manifest_lines.append(f"Generated: {datetime.utcnow().isoformat()}Z\n\n")
    manifest_lines.append("Implementation files:\n")
    
    for py_file in sorted(Path(__file__).parent.glob("*.py")):
        if not py_file.name.startswith("test_case"):
            try:
                hash_value = compute_sha256(py_file)
                manifest_lines.append(f"  {hash_value}  {py_file.name}\n")
            except:
                pass
    
    return "".join(manifest_lines)


def generate_dependency_manifest() -> str:
    """Generate dependency manifest."""
    return """DEPENDENCY MANIFEST
================================================================================

All dependencies are self-contained in this package.

No external repositories required.
No hidden files required.
Standard library only (unittest, dataclasses, json, hashlib).
"""


def main():
    parser = argparse.ArgumentParser(description="Phase 1 validation")
    parser.add_argument("--output-dir", default="./validation_output", help="Output directory")
    args = parser.parse_args()
    
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print("\n" + "=" * 80)
    print("PHASE 1 COMPLETE VALIDATION")
    print("=" * 80 + "\n")
    
    # Run suites
    baseline_success, baseline_report, baseline_count = run_baseline_tests()
    regression_success, regression_report = run_regression_tests()
    mutation_success, mutation_report, mutation_data = run_mutation_tests()
    transition_success, transition_report = validate_state_transitions()
    
    # Generate execution trace
    case = build_gold_case_refgrounded_007_valeriana_officinalis_preparation_spec()
    engine_result = EngineExecutor.execute_case(case)
    execution_trace = generate_execution_trace(case, engine_result)
    
    # Final result
    print("\n" + "=" * 80)
    print("FINAL RESULTS")
    print("=" * 80)
    
    overall_success = (
        baseline_success
        and regression_success
        and mutation_success
        and transition_success
    )
    
    print(f"\nBaseline: {'PASS' if baseline_success else 'FAIL'}")
    print(f"Regression: {'PASS' if regression_success else 'FAIL'}")
    print(f"Mutation detection: {100*mutation_data['detection_rate']:.1f}% ({'PASS' if mutation_success else 'FAIL'})")
    print(f"State transitions: {'PASS' if transition_success else 'FAIL'}")
    print(f"\nOverall result: {'✓ PASSED' if overall_success else '✗ FAILED'}")
    print("=" * 80)
    
    # Write output files
    print(f"\nWriting output files to {output_dir}...")
    
    (output_dir / "baseline_results.txt").write_text(baseline_report)
    (output_dir / "regression_results.txt").write_text(regression_report)
    (output_dir / "mutation_results.txt").write_text(mutation_report)
    (output_dir / "state_transition_results.txt").write_text(transition_report)
    
    execution_report = {
        "phase": "PHASE_1",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "suites": {
            "baseline": {
                "success": baseline_success,
                "tests_run": baseline_count,
            },
            "regression": {
                "success": regression_success,
            },
            "mutation": {
                "success": mutation_success,
                "mutations_injected": mutation_data['mutations_injected'],
                "mutations_killed": mutation_data['mutations_killed'],
                "detection_rate": mutation_data['detection_rate'],
            },
            "state_transitions": {
                "success": transition_success,
            },
        },
        "overall": {
            "success": overall_success,
        },
    }
    
    (output_dir / "execution_report.json").write_text(json.dumps(execution_report, indent=2))
    (output_dir / "execution_trace.json").write_text(json.dumps(execution_trace, indent=2))
    (output_dir / "sha256_manifest.txt").write_text(generate_sha256_manifest(output_dir))
    (output_dir / "dependency_manifest.txt").write_text(generate_dependency_manifest())
    (output_dir / "stdout.log").write_text("")
    (output_dir / "stderr.log").write_text("")
    
    print(f"✓ Output files written")
    print(f"\nGenerated files:")
    for f in sorted(output_dir.glob("*.txt")):
        print(f"  ✓ {f.name}")
    for f in sorted(output_dir.glob("*.json")):
        print(f"  ✓ {f.name}")
    
    return 0 if overall_success else 1


if __name__ == "__main__":
    sys.exit(main())
