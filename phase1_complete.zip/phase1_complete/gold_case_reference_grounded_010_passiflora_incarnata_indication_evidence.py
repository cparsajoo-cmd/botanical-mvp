"""
gold_case_reference_grounded_010_passiflora_incarnata_indication_evidence.py

Case 010: Passiflora incarnata L. (aerial parts)
Domain: INDICATION_EVIDENCE

Clinical evidence for anxiety reduction in preoperative and general anxiety.

SOURCE:
  - Aslanargun P, Cuvas O, Dikmen B, Aslanargun H, Celiker V. (2012)
    Passiflora incarnata Linneaus as an anxiolytic before spinal anesthesia
    Journal of Anesthesia, 26(1):39-44
    PMID: 21986843
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from applicability_check import check_applicability, ReferenceDomain
from assertion_vocabulary import AssertionState, AssertionType, ExtractionConfidenceLevel
from gold_case import GoldCase, GoldCaseReference
from reference_claim import ReferenceClaim, ExtractionConfidence, NormalizedEvidenceText
from reference_descriptor import ReferenceDescriptor
from resolved_expected_outcome import resolve_expected_outcomes
from validation_unit import ValidationUnit


def _build_validation_unit() -> ValidationUnit:
    """Build validation unit for Passiflora incarnata aerial parts, anxiety indication."""
    return ValidationUnit(
        taxon="Passiflora incarnata L.",
        plant_part="aerial parts",
        indication="anxiety reduction, preoperative anxiety management",
        population="Adults with anxiety or requiring anxiolytic support",
        jurisdiction="EU",
    )


def _build_reference_descriptor() -> ReferenceDescriptor:
    """Build reference descriptor for Passiflora anxiety indication evidence."""
    return ReferenceDescriptor(
        reference_id="Aslanargun_2012_passiflora_anxiety",
        source_type="Journal Article",
        version="Published",
        document_date=date(2012, 1, 1),
        jurisdiction="EU",
        taxon="Passiflora incarnata L.",
        plant_part="aerial parts",
        population="Adult patients undergoing spinal anesthesia",
        indication_scope=["anxiety reduction", "preoperative anxiety"],
        route_scope=["Oral"],
        claim_type="indication-evidence",
    )


def _build_reference_claim() -> ReferenceClaim:
    """Build reference claim for Passiflora anxiety reduction evidence."""
    return ReferenceClaim(
        domain=ReferenceDomain.INDICATION_EVIDENCE,
        assertion_type=AssertionType.SUPPORTS_INDICATION,
        subject="anxiety reduction in adults requiring anxiolytic support",
        assertion_state=AssertionState.PRESENT,
        severity=None,
        source_reference_id="Aslanargun_2012_passiflora_anxiety",
        source_locator="Journal of Anesthesia, 26(1):39-44, DOI: 10.1007/s00540-011-1250-1",
        evidence_text=NormalizedEvidenceText(
            original_text=(
                "Passiflora incarnata extract demonstrated significant anxiolytic effects "
                "in adult patients, with measurable reduction in preoperative anxiety scores. "
                "The extract showed efficacy comparable to standard anxiolytic medication "
                "in clinical trial settings."
            ),
            normalized_text=(
                "Passiflora incarnata reduces anxiety in adults requiring anxiolytic support"
            ),
            transformation_type="PARAPHRASED",
            transformation_version="v1",
            source_locator="Aslanargun P, et al. (2012) Journal of Anesthesia 26(1):39-44, PMID: 21986843",
        ),
        extraction_confidence=ExtractionConfidence(
            level=ExtractionConfidenceLevel.MEDIUM,
            basis="Randomized controlled trial in clinical setting with anxiety outcome measures",
            extractor_type="botanical-evidence-curator",
            extractor_version="v1",
        ),
    )


def build_gold_case_refgrounded_010_passiflora_incarnata_indication_evidence() -> GoldCase:
    """Build Case 010: Passiflora incarnata aerial parts anxiety indication evidence."""
    unit = _build_validation_unit()
    reference_descriptor = _build_reference_descriptor()
    reference_claim = _build_reference_claim()
    
    reference = GoldCaseReference(
        reference=reference_descriptor,
        claims=[reference_claim],
    )
    reference.applicability_by_domain[ReferenceDomain.INDICATION_EVIDENCE] = check_applicability(
        reference_descriptor, unit, ReferenceDomain.INDICATION_EVIDENCE
    )
    
    case = GoldCase(
        case_id="refgrounded_010_passiflora_incarnata_indication_evidence",
        validation_unit=unit,
        references=[reference],
        engine_evidence=[],
        engine_evidence_origin=None,
        risk_strata=[],
        kind="REFERENCE_GROUNDED",
        curation_status="REFERENCE_CURATED",
        locked=False,
    )
    
    # Resolve expected outcomes from the claim
    case = replace(case, resolved_outcomes=resolve_expected_outcomes(case))
    
    return case


if __name__ == "__main__":
    case = build_gold_case_refgrounded_010_passiflora_incarnata_indication_evidence()
    print(f"case_id: {case.case_id}")
    print(f"domain: INDICATION_EVIDENCE")
    print(f"resolved_outcomes: {len(case.resolved_outcomes)}")
