"""
pipeline_state_machine.py

Corrected state machine with explicit legal transition map.

LEGAL TRANSITIONS:
  DISCOVERED → SOURCE_RETRIEVED
  SOURCE_RETRIEVED → SOURCE_VERIFIED (if VerificationStatus.VERIFIED)
  SOURCE_VERIFIED → EVIDENCE_EXTRACTED (if evidence quotes valid)
  EVIDENCE_EXTRACTED → READY_FOR_ENGINE (if no hard-coded logic)
  READY_FOR_ENGINE → ENGINE_VALIDATED (if engine result obtained)
  ENGINE_VALIDATED → TEST_VALIDATED (if tests pass)
  TEST_VALIDATED → SUPERVISOR_APPROVED (if approval record valid)

ILLEGAL TRANSITIONS (will raise error):
  - Skip states (e.g. DISCOVERED → ENGINE_VALIDATED)
  - Backward transitions (e.g. ENGINE_VALIDATED → SOURCE_RETRIEVED)
  - Invalid same-state transitions
  - Advancement without valid gate artifacts
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
import hashlib


class PipelineState(str, Enum):
    """8 lifecycle states - strict sequence only."""
    DISCOVERED = "DISCOVERED"
    SOURCE_RETRIEVED = "SOURCE_RETRIEVED"
    SOURCE_VERIFIED = "SOURCE_VERIFIED"
    EVIDENCE_EXTRACTED = "EVIDENCE_EXTRACTED"
    READY_FOR_ENGINE = "READY_FOR_ENGINE"
    ENGINE_VALIDATED = "ENGINE_VALIDATED"
    TEST_VALIDATED = "TEST_VALIDATED"
    SUPERVISOR_APPROVED = "SUPERVISOR_APPROVED"


class VerificationStatus(str, Enum):
    PENDING = "PENDING"
    VERIFIED = "VERIFIED"
    FAILED = "FAILED"


@dataclass
class VerificationRecord:
    """Proof of source verification."""
    verification_status: VerificationStatus
    verified_metadata: Optional[Dict[str, Any]] = None
    retrieval_method: Optional[str] = None
    retrieval_date: Optional[str] = None
    retrieved_by: Optional[str] = None
    archive_type: Optional[str] = None
    archive_url: Optional[str] = None
    archive_hash: Optional[str] = None
    verified_evidence_quotes: List[Dict[str, Any]] = field(default_factory=list)
    verifier_identity: Optional[str] = None
    verification_timestamp: Optional[str] = None

    def is_complete(self) -> bool:
        """All required fields present."""
        return (
            self.verification_status == VerificationStatus.VERIFIED
            and self.verified_metadata is not None
            and self.retrieval_method is not None
            and self.verified_evidence_quotes
            and self.verifier_identity is not None
            and self.verification_timestamp is not None
        )


@dataclass
class EvidenceQuote:
    """Single piece of evidence with locator."""
    quote_text: str
    source_id: str
    locator: str
    transformation_type: str  # VERBATIM, PARAPHRASED, etc.

    def is_valid(self) -> bool:
        """All required fields non-empty."""
        return bool(self.quote_text and self.source_id and self.locator)


@dataclass
class EngineExecutionResult:
    """Result of production engine execution."""
    success: bool
    case_id: str
    resolved_outcomes: List[Dict[str, Any]] = field(default_factory=list)
    execution_timestamp: Optional[str] = None
    execution_trace: List[str] = field(default_factory=list)
    exception_message: Optional[str] = None


@dataclass
class TestExecutionResult:
    """Result of subprocess test execution."""
    return_code: int
    tests_collected: int
    tests_passed: int
    tests_failed: int
    tests_errored: int
    execution_timestamp: Optional[str] = None

    def is_successful(self) -> bool:
        """Tests passed without failure."""
        return (
            self.return_code == 0
            and self.tests_failed == 0
            and self.tests_errored == 0
        )


@dataclass
class ApprovalRecord:
    """Supervisor approval decision."""
    approver_identity: str
    approval_timestamp: str
    decision: str  # Must be exactly "APPROVED"
    reason: str
    artifact_hashes: Dict[str, str] = field(default_factory=dict)

    def is_valid(self) -> bool:
        """All required fields present and non-empty."""
        return (
            bool(self.approver_identity)
            and bool(self.approval_timestamp)
            and self.decision == "APPROVED"
            and bool(self.reason)
            and bool(self.artifact_hashes)
            and all(self._is_valid_sha256(h) for h in self.artifact_hashes.values())
        )

    @staticmethod
    def _is_valid_sha256(hash_str: str) -> bool:
        """Validate SHA-256 format."""
        return bool(hash_str) and len(hash_str) == 64 and all(c in "0123456789abcdef" for c in hash_str.lower())


# Legal transitions map
LEGAL_TRANSITIONS = {
    PipelineState.DISCOVERED: [PipelineState.SOURCE_RETRIEVED],
    PipelineState.SOURCE_RETRIEVED: [PipelineState.SOURCE_VERIFIED],
    PipelineState.SOURCE_VERIFIED: [PipelineState.EVIDENCE_EXTRACTED],
    PipelineState.EVIDENCE_EXTRACTED: [PipelineState.READY_FOR_ENGINE],
    PipelineState.READY_FOR_ENGINE: [PipelineState.ENGINE_VALIDATED],
    PipelineState.ENGINE_VALIDATED: [PipelineState.TEST_VALIDATED],
    PipelineState.TEST_VALIDATED: [PipelineState.SUPERVISOR_APPROVED],
    PipelineState.SUPERVISOR_APPROVED: [],  # Terminal state
}


@dataclass
class PipelineStateRecord:
    """Complete pipeline state with artifacts."""
    case_id: str
    current_state: PipelineState = PipelineState.DISCOVERED
    verification_status: VerificationStatus = VerificationStatus.PENDING
    
    # Proof artifacts
    verification_record: Optional[VerificationRecord] = None
    engine_result: Optional[EngineExecutionResult] = None
    test_result: Optional[TestExecutionResult] = None
    approval_record: Optional[ApprovalRecord] = None
    
    # Timeline
    created_timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
    updated_timestamp: Optional[str] = None
    
    def advance_to_state(self, new_state: PipelineState) -> Tuple[bool, Optional[str]]:
        """
        Advance state with validation.
        
        Returns: (success, error_message)
        """
        
        # Check if transition is legal
        if new_state not in LEGAL_TRANSITIONS.get(self.current_state, []):
            return False, f"Illegal transition: {self.current_state} → {new_state}"
        
        # Enforce gate before transition
        if new_state == PipelineState.SOURCE_VERIFIED:
            if self.verification_status != VerificationStatus.VERIFIED:
                return False, "SOURCE_VERIFIED requires VerificationStatus.VERIFIED"
            if not self.verification_record or not self.verification_record.is_complete():
                return False, "VerificationRecord incomplete"
        
        elif new_state == PipelineState.EVIDENCE_EXTRACTED:
            if not self.verification_record or not self.verification_record.verified_evidence_quotes:
                return False, "EVIDENCE_EXTRACTED requires verified evidence quotes"
            # Validate each quote
            for quote_dict in self.verification_record.verified_evidence_quotes:
                quote = EvidenceQuote(**quote_dict)
                if not quote.is_valid():
                    return False, "Evidence quote missing required fields"
        
        elif new_state == PipelineState.ENGINE_VALIDATED:
            if not self.engine_result or not self.engine_result.success:
                return False, "ENGINE_VALIDATED requires successful engine execution"
        
        elif new_state == PipelineState.TEST_VALIDATED:
            if not self.test_result or not self.test_result.is_successful():
                return False, "TEST_VALIDATED requires tests to pass"
        
        elif new_state == PipelineState.SUPERVISOR_APPROVED:
            if not self.approval_record or not self.approval_record.is_valid():
                return False, "SUPERVISOR_APPROVED requires valid ApprovalRecord"
        
        # Transition valid
        self.current_state = new_state
        self.updated_timestamp = datetime.utcnow().isoformat() + "Z"
        return True, None
