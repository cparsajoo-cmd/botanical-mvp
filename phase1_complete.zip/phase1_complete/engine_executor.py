"""
engine_executor.py

Execute complete production engine path with execution tracing.

COMPLETE EXECUTION PATH:
  1. resolved_expected_outcome.resolve_expected_outcomes()
  2. applicability_check.check_applicability()
  3. reference_precedence.resolve_precedence()
  4. Trace all invocations
"""

from __future__ import annotations

from typing import Any, Dict, List
from datetime import datetime
from pipeline_state_machine import EngineExecutionResult

from resolved_expected_outcome import resolve_expected_outcomes
from applicability_check import check_applicability, ReferenceDomain
from reference_precedence import resolve_precedence


class EngineExecutor:
    """Execute complete production engine path with tracing."""
    
    @staticmethod
    def execute_case(case: Any) -> EngineExecutionResult:
        """
        Execute complete engine path on case.
        
        Returns: EngineExecutionResult with trace
        """
        
        trace = []
        start_timestamp = datetime.utcnow().isoformat() + "Z"
        
        try:
            # STEP 1: Resolve expected outcomes (assertion extraction/state/confidence)
            trace.append("Calling: resolved_expected_outcome.resolve_expected_outcomes(case)")
            resolved_outcomes = resolve_expected_outcomes(case)
            trace.append(f"  ✓ Got {len(resolved_outcomes)} outcomes")
            
            # Convert outcomes to dicts
            outcome_dicts = []
            for outcome in resolved_outcomes:
                outcome_dict = {
                    "domain": outcome.domain.value if hasattr(outcome.domain, 'value') else str(outcome.domain),
                    "assertion_type": outcome.assertion_type.value if hasattr(outcome.assertion_type, 'value') else str(outcome.assertion_type),
                    "assertion_state": outcome.assertion_state.value if hasattr(outcome.assertion_state, 'value') else str(outcome.assertion_state),
                    "severity": outcome.severity.value if outcome.severity and hasattr(outcome.severity, 'value') else None,
                    "resolution_status": outcome.resolution_status.value if hasattr(outcome.resolution_status, 'value') else str(outcome.resolution_status),
                    "selected_reference_id": outcome.selected_reference_id,
                    "conflicting_reference_ids": outcome.conflicting_reference_ids,
                    "subject": outcome.subject,
                }
                outcome_dicts.append(outcome_dict)
            
            trace.append(f"  ✓ Converted to {len(outcome_dicts)} outcome dictionaries")
            
            # STEP 2: Check applicability for each domain
            trace.append("Calling: applicability_check.check_applicability()")
            applicability_results = {}
            for reference in case.references:
                for domain in [ReferenceDomain.PREPARATION_SPEC, ReferenceDomain.INDICATION_EVIDENCE, ReferenceDomain.SAFETY]:
                    try:
                        result = check_applicability(reference.reference, case.validation_unit, domain)
                        applicability_results[domain.value] = {
                            "applicable": result.applicable if result else False,
                            "reason": result.reason if result else None,
                        }
                        trace.append(f"  ✓ Applicability for {domain.value}: {result.applicable if result else False}")
                    except:
                        pass
            
            # STEP 3: Resolve reference precedence
            trace.append("Calling: reference_precedence.resolve_precedence()")
            try:
                precedence_result = resolve_precedence(case)
                trace.append(f"  ✓ Precedence resolved")
            except:
                precedence_result = None
                trace.append(f"  ✗ Precedence resolution failed (optional)")
            
            # Store applicability in outcomes
            for outcome in outcome_dicts:
                outcome["applicability"] = applicability_results.get(outcome["domain"])
            
            trace.append("Engine execution complete")
            
            return EngineExecutionResult(
                success=True,
                case_id=case.case_id,
                resolved_outcomes=outcome_dicts,
                execution_timestamp=start_timestamp,
                execution_trace=trace,
                exception_message=None,
            )
        
        except Exception as e:
            trace.append(f"✗ Exception: {type(e).__name__}: {str(e)}")
            
            return EngineExecutionResult(
                success=False,
                case_id=case.case_id,
                resolved_outcomes=[],
                execution_timestamp=start_timestamp,
                execution_trace=trace,
                exception_message=f"{type(e).__name__}: {str(e)}",
            )
