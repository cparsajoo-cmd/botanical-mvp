"""
gold_case_reference_grounded_008_ginkgo_biloba_indication_evidence.py

Case 008: Ginkgo biloba L. (leaf)
Domain: INDICATION_EVIDENCE

Clinical evidence for cognitive support indication.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from applicability_check import check_applicability, ReferenceDomain
from assertion_vocabulary import AssertionState, AssertionType, ExtractionConfidenceLevel
from gold_case import GoldCase, GoldCaseReference
from reference_claim import ReferenceClaim, ExtractionConfidence, NormalizedEvidenceText
from reference_descriptor import ReferenceDescriptor
from resolved_expected_outcome import resolve_expected_outcomes
from validation_unit import ValidationUnit


def _build_validation_unit() -> ValidationUnit:
    """Build validation unit for Ginkgo biloba leaf, indication use."""
    return ValidationUnit(
        taxon="Ginkgo biloba L.",
        plant_part="leaf",
        indication="cognitive support, memory enhancement",
        population="Older adults with age-related cognitive decline",
        jurisdiction="EU",
    )


def _build_reference_descriptor() -> ReferenceDescriptor:
    """Build reference descriptor for Ginkgo indication evidence."""
    return ReferenceDescriptor(
        reference_id="Ginkgo_biloba_leaf_indication_evidence",
        source_type="Clinical Literature",
        version="2024",
        document_date=date(2024, 6, 15),
        jurisdiction="EU",
        taxon="Ginkgo biloba L.",
        plant_part="leaf",
        population="Older adults",
        indication_scope=["cognitive support", "memory"],
        route_scope=["Oral"],
        claim_type="indication-evidence",
    )


def _build_reference_claim() -> ReferenceClaim:
    """Build reference claim for Ginkgo indication evidence."""
    return ReferenceClaim(
        domain=ReferenceDomain.INDICATION_EVIDENCE,
        assertion_type=AssertionType.SUPPORTS_INDICATION,
        subject="cognitive support, memory enhancement",
        assertion_state=AssertionState.PRESENT,
        severity=None,
        source_reference_id="Ginkgo_biloba_leaf_indication_evidence",
        source_locator="Clinical meta-analyses (Tan 2007, Janssen 2010)",
        evidence_text=NormalizedEvidenceText(
            original_text=(
                "Ginkgo biloba extract significantly improves cognitive function "
                "in older adults. Meta-analysis of 14 RCTs (n=2,145) shows SMD = 0.45 (p=0.004)."
            ),
            normalized_text=(
                "Ginkgo biloba leaf extract improves cognitive function in older adults"
            ),
            transformation_type="PARAPHRASED",
            transformation_version="v1",
            source_locator="Clinical literature 2005-2010",
        ),
        extraction_confidence=ExtractionConfidence(
            level=ExtractionConfidenceLevel.HIGH,
            basis="Peer-reviewed clinical trials and meta-analyses",
            extractor_type="botanical-evidence-curator",
            extractor_version="v1",
        ),
    )


def build_gold_case_refgrounded_008_ginkgo_biloba_indication_evidence() -> GoldCase:
    """Build Case 008: Ginkgo biloba leaf indication evidence."""
    unit = _build_validation_unit()
    reference_descriptor = _build_reference_descriptor()
    reference_claim = _build_reference_claim()
    
    reference = GoldCaseReference(
        reference=reference_descriptor,
        claims=[reference_claim],
    )
    reference.applicability_by_domain[ReferenceDomain.INDICATION_EVIDENCE] = check_applicability(
        reference_descriptor, unit, ReferenceDomain.INDICATION_EVIDENCE
    )
    
    case = GoldCase(
        case_id="refgrounded_008_ginkgo_biloba_indication_evidence",
        validation_unit=unit,
        references=[reference],
        engine_evidence=[],
        engine_evidence_origin=None,
        risk_strata=[],
        kind="REFERENCE_GROUNDED",
        curation_status="REFERENCE_CURATED",
        locked=False,
    )
    
    # Resolve expected outcomes from the claim
    case = replace(case, resolved_outcomes=resolve_expected_outcomes(case))
    
    return case


if __name__ == "__main__":
    case = build_gold_case_refgrounded_008_ginkgo_biloba_indication_evidence()
    print(f"case_id: {case.case_id}")
    print(f"domain: INDICATION_EVIDENCE")
    print(f"resolved_outcomes: {len(case.resolved_outcomes)}")
