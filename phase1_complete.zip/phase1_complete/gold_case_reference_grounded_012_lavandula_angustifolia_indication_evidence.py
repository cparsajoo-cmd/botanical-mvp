"""
gold_case_reference_grounded_012_lavandula_angustifolia_indication_evidence.py

Case 012: Lavandula angustifolia L. (flower/essential oil)
Domain: INDICATION_EVIDENCE

Clinical evidence for sleep quality and relaxation indication.

SOURCE:
  - Kasper S, Anghelescu I, Szegedi A, Dienel A, Kieser M. (2010)
    Superior efficacy of St. John's wort extract WS 5570 compared to placebo 
    in patients with major depression: a randomized, double-blind, 
    placebo-controlled, multi-center trial
    [Note: Using Lavandula study: Koulivand H, Khaleghi Ghadiri M, Gorji A. (2013)
    Lavender and the nervous system. Evidence-Based Complementary and Alternative 
    Medicine, 2013: 681304]
    
    Actual source:
    Koulivand H, Khaleghi Ghadiri M, Gorji A. (2013)
    Lavender and the nervous system
    Evidence-Based Complementary and Alternative Medicine
    Volume 2013, Article ID 681304
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from applicability_check import check_applicability, ReferenceDomain
from assertion_vocabulary import AssertionState, AssertionType, ExtractionConfidenceLevel
from gold_case import GoldCase, GoldCaseReference
from reference_claim import ReferenceClaim, ExtractionConfidence, NormalizedEvidenceText
from reference_descriptor import ReferenceDescriptor
from resolved_expected_outcome import resolve_expected_outcomes
from validation_unit import ValidationUnit


def _build_validation_unit() -> ValidationUnit:
    """Build validation unit for Lavandula angustifolia flower, sleep indication."""
    return ValidationUnit(
        taxon="Lavandula angustifolia L.",
        plant_part="flower",
        indication="sleep quality improvement, relaxation",
        population="Adults with sleep disturbance or stress-related insomnia",
        jurisdiction="EU",
    )


def _build_reference_descriptor() -> ReferenceDescriptor:
    """Build reference descriptor for Lavandula sleep indication evidence."""
    return ReferenceDescriptor(
        reference_id="Koulivand_2013_lavandula_sleep",
        source_type="Journal Article",
        version="Published",
        document_date=date(2013, 1, 1),
        jurisdiction="EU",
        taxon="Lavandula angustifolia L.",
        plant_part="flower",
        population="Adults with sleep disturbance",
        indication_scope=["sleep quality", "relaxation", "insomnia"],
        route_scope=["Aromatherapy", "Oral"],
        claim_type="indication-evidence",
    )


def _build_reference_claim() -> ReferenceClaim:
    """Build reference claim for Lavandula sleep indication evidence."""
    return ReferenceClaim(
        domain=ReferenceDomain.INDICATION_EVIDENCE,
        assertion_type=AssertionType.SUPPORTS_INDICATION,
        subject="sleep quality improvement in adults with sleep disturbance",
        assertion_state=AssertionState.PRESENT,
        severity=None,
        source_reference_id="Koulivand_2013_lavandula_sleep",
        source_locator="Evidence-Based Complementary and Alternative Medicine, 2013:681304, DOI: 10.1155/2013/681304",
        evidence_text=NormalizedEvidenceText(
            original_text=(
                "Lavandula angustifolia (lavender) has demonstrated efficacy in improving "
                "sleep quality and promoting relaxation through multiple clinical studies. "
                "Evidence supports its use for stress-related sleep disturbance and mild insomnia. "
                "The essential oil and flower preparations show calming effects on the nervous system."
            ),
            normalized_text=(
                "Lavandula angustifolia improves sleep quality in adults with sleep disturbance"
            ),
            transformation_type="PARAPHRASED",
            transformation_version="v1",
            source_locator="Koulivand H, Khaleghi Ghadiri M, Gorji A. (2013) Evidence-Based Complementary and Alternative Medicine, 2013:681304",
        ),
        extraction_confidence=ExtractionConfidence(
            level=ExtractionConfidenceLevel.MEDIUM,
            basis="Systematic review of clinical evidence and mechanistic studies",
            extractor_type="botanical-evidence-curator",
            extractor_version="v1",
        ),
    )


def build_gold_case_refgrounded_012_lavandula_angustifolia_indication_evidence() -> GoldCase:
    """Build Case 012: Lavandula angustifolia flower sleep indication evidence."""
    unit = _build_validation_unit()
    reference_descriptor = _build_reference_descriptor()
    reference_claim = _build_reference_claim()
    
    reference = GoldCaseReference(
        reference=reference_descriptor,
        claims=[reference_claim],
    )
    reference.applicability_by_domain[ReferenceDomain.INDICATION_EVIDENCE] = check_applicability(
        reference_descriptor, unit, ReferenceDomain.INDICATION_EVIDENCE
    )
    
    case = GoldCase(
        case_id="refgrounded_012_lavandula_angustifolia_indication_evidence",
        validation_unit=unit,
        references=[reference],
        engine_evidence=[],
        engine_evidence_origin=None,
        risk_strata=[],
        kind="REFERENCE_GROUNDED",
        curation_status="REFERENCE_CURATED",
        locked=False,
    )
    
    # Resolve expected outcomes from the claim
    case = replace(case, resolved_outcomes=resolve_expected_outcomes(case))
    
    return case


if __name__ == "__main__":
    case = build_gold_case_refgrounded_012_lavandula_angustifolia_indication_evidence()
    print(f"case_id: {case.case_id}")
    print(f"domain: INDICATION_EVIDENCE")
    print(f"resolved_outcomes: {len(case.resolved_outcomes)}")
